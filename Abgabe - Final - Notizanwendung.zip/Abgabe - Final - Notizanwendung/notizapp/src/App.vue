<template>
  <div class="app-container">
    <note-list @note-selected="selectNote" :notes="notes" :selected-note="selectedNote"></note-list>
    <note-detail v-if="selectedNote" :note="selectedNote" :availableTags="availableTags"></note-detail>
    <tag-detail :tags="availableTags"></tag-detail>
  </div>
</template>

<script> // Hier werden die anderen Ansichten importiert
import NoteList from './NoteList.vue';
import NoteDetail from './NoteDetail.vue';
import TagDetail from './TagDetail.vue';

export default {
  name: 'App',
  components: {
    NoteList,
    NoteDetail,
    TagDetail
  },
  data() {
    return {
      notes: [],
      selectedNote: null,
      availableTags: []
    };
  },
  async created() {
    await this.fetchNotes();
    await this.fetchTags(); 
  },
  methods: {
    async fetchNotes() {
      // Implementierung von fetchNotes
    },
    async fetchTags() {
  try {
    const response = await fetch('http://localhost:3000/tags', { method: 'GET' });
    if (!response.ok) throw new Error('Failed to fetch tags');
    this.availableTags = await response.json();
  } catch (error) {
    console.error('Error fetching tags:', error);
  }
},
    selectNote(note) {
      this.selectedNote = note;
    }
  }
}
</script>

<style>
.app-container {
  display: flex;
  height: 100vh; 
  flex-direction: row; 
}

.note-list {
  flex: 1; 
  min-width: 250px; 
}

.note-detail {
  flex: 2; 
}

.tag-detail {
  flex: 1;
}
</style>