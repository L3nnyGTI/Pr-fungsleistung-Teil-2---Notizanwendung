<template>
  <div class="note-detail">
    <div class="note-header">
      <input v-model="localNote.title" placeholder="Titel der Notiz" class="note-title-input"/>
      <button @click="saveNote" class="save-button">Speichern</button>
    </div>
    <textarea v-model="localNote.content" placeholder="Notizinhalt" class="note-content-textarea"></textarea>
    <div class="tag-list">
      <div v-for="tag in availableTags" :key="tag._id" class="tag-item">
        <input type="checkbox" :id="tag._id" v-model="tag.checked">
        <label :for="tag._id">{{ tag.name }}</label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    note: Object
  },
  data() {
    return {
      localNote: null,
      availableTags: []
    };
  },
  created() {
    this.fetchTags();
  },
  watch: {
    note: {
      immediate: true,
      handler(newVal) {
        if (newVal) {
          this.localNote = { ...newVal };
        } else {
          this.localNote = { title: '', content: '', tags: [] };
        }
        this.matchTagsWithNote();
      }
    }
  },
  methods: {
    async fetchTags() {
      try {
        const response = await fetch('http://localhost:3000/tags');
        if (!response.ok) {
          throw new Error('Failed to fetch tags');
        }
        this.availableTags = await response.json();
        this.matchTagsWithNote();
      } catch (error) {
        console.error('Error fetching tags:', error);
      }
    },
    matchTagsWithNote() { // Kombiniert Notizen mit dem gewünschen Tags
      if (!this.localNote || !this.availableTags) return;

      this.availableTags.forEach(tag => {
        tag.checked = this.localNote.tags && this.localNote.tags.includes(tag._id);
      });
    },
    async saveNote() {
  const selectedTags = this.availableTags.filter(tag => tag.checked).map(tag => tag._id);
  this.localNote.tags = selectedTags;

  try {
    if (this.localNote._id) {
      const response = await fetch(`http://localhost:3000/notes/${this.localNote._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(this.localNote)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update the note');
      }

      const updatedNote = await response.json();
      this.$emit('note-updated', updatedNote);
      alert('Note updated successfully');
    } else {
      const response = await fetch('http://localhost:3000/notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(this.localNote)
      });

      if (!response.ok) {
        throw new Error('Failed to save the note');
      }

      const newNote = await response.json();
      this.$emit('note-updated', newNote);
      alert('Note saved successfully');
    }

    
    window.location.reload();
  } catch (error) {
    console.error('Error saving note:', error);
    alert('Error saving note');
  }
}
  }
};
</script>

<style scoped>
.note-detail {
  display: flex;
  flex-direction: column;
}

.note-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.note-title-input {
  flex-grow: 1;
  margin-right: 10px;
}

.save-button {
  padding: 5px 10px;
  font-size: 1em;
}

.note-content-textarea {
  flex-grow: 1;
  width: 100%;
  margin: 10px 0;
  resize: vertical;
}

.tag-list {
  display: flex;
  flex-wrap: wrap;
  margin-top: 10px;
}

.tag-item {
  margin: 5px 10px 5px 0;
}
</style>