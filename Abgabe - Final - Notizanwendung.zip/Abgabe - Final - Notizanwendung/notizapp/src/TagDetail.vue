<template>
    <div class="tag-detail">
      <h2 class="tag-detail-title">Ihre Tags</h2>
      <button @click="showCreateForm = !showCreateForm" class="new-tag-button">Neuer Tag</button>
  
      <div v-if="showCreateForm" class="create-tag-form">
        <input type="text" v-model="newTag.name" placeholder="Tag-Name" />
        <textarea v-model="newTag.description" placeholder="Beschreibung"></textarea>
        <button @click="createNewTag" class="save-tag-button">Speichern</button>
      </div>
  
      <div class="tag-list">
        <div v-for="tag in tags" :key="tag._id" class="tag-item">
          <h3>{{ tag.name }}</h3>
          <p>{{ tag.description }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'TagDetail',
    props: {
      tags: Array
    },
    data() {
      return {
        showCreateForm: false,
        newTag: {
          name: '',
          description: ''
        }
      };
    },
    methods: { // Neuen Tag erstellen
      async createNewTag() {
        try {
          const response = await fetch('http://localhost:3000/tags', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(this.newTag)
          });
          if (!response.ok) {
            throw new Error('Failed to create new tag');
          }
          location.reload();
        } catch (error) {
          console.error('Error creating new tag:', error);
          alert('Fehler beim Speichern des neuen Tags');
        }
      }
    }
  }
  </script>
  
  <style scoped>
  .tag-detail {
    width: auto;
    min-width: 250px;
    max-width: 30%;
    overflow-y: auto;
    background-color: #f0f0f0;
    padding: 10px;
    margin: 0;
  }
  
  .tag-detail-title {
    padding: 10px;
    margin: 0;
    background-color: #f0f0f0;
    border-bottom: 1px solid #ddd;
  }
  
  .tag-list {
    margin-top: 10px;
  }
  
  .tag-item {
    margin: 5px 0;
    padding: 5px;
    background-color: #e9e9e9;
    border-radius: 5px;
  }
  
  .new-tag-button {
    padding: 10px;
    margin: 10px 0;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  
  .new-tag-button:hover {
    background-color: #0056b3;
  }
  </style>