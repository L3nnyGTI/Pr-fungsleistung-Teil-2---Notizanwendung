<template>
  <div class="note-list">
    <h2 class="note-list-title">Ihre Notizen</h2>
    <button @click="createNewNote" class="new-note-button">Neue Notiz</button>
    <div v-for="note in notes" :key="note._id"
         @click="selectNote(note)"
         :class="{'note-item': true, 'selected-note': selectedNote && note._id === selectedNote._id}">
      {{ note.title }}
    </div>
  </div>
</template>

<script>
export default {
  name: 'NoteList',
  props: {
    selectedNote: Object
  },
  data() {
    return {
      notes: []
    };
  },
  created() {
    this.fetchNotes();
  },
  methods: {
    fetchNotes() {
      fetch('http://localhost:3000/notes')
        .then(response => response.json())
        .then(data => {
          this.notes = data;
        })
        .catch(error => {
          console.error('Error fetching notes:', error);
        });
    },
    selectNote(note) {
    this.$emit('note-selected', note);
  },
    createNewNote() { // Neue Notiz erstellen
      const newNote = {
        title: 'Neue Notiz',
        content: '',
        tags: []
      };

      fetch('http://localhost:3000/notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newNote)
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to create new note');
        }
        return response.json();
      })
      .then(createdNote => {
        if (createdNote.title === 'Neue Notiz' && createdNote.content === '' && createdNote.tags.length === 0) {
          alert('Die neue Notiz wurde erstellt, aber leer gelassen.');
        } else {
          this.notes.push(createdNote);
          this.selectNote(createdNote);
        }
      })
      .catch(error => {
        console.error('Error creating new note:', error);
      });
    }
  }
}
</script>

<style scoped>
.note-list {
  width: auto;
  min-width: 250px;
  max-width: 30%;
  overflow-y: auto;
}

.note-list-title {
  background-color: #f0f0f0;
  padding: 10px;
  margin: 0;
}

.note-item {
  padding: 10px;
  border-bottom: 1px solid #ddd;
  cursor: pointer;
  transition: background-color 0.3s;
}

.note-item:hover {
  background-color: #e9e9e9;
}

.selected-note {
  border: 2px solid black;
}

.new-note-button {
  padding: 10px;
  margin: 10px 0;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.new-note-button:hover {
  background-color: #0056b3;
}
</style>